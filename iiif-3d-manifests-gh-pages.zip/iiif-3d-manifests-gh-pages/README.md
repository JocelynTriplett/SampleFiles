# iiif-3d-manifests

https://edsilv.github.io/iiif-3d-manifests